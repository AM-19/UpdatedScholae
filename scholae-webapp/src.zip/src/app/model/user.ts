export class User {
  emailId : string;
  phoneNumber : number;
  password : string;
  address: string;
  userRole : any;
  subscriptionPlan: any;

}
