import { AuthUser } from './auth-user';

describe('AuthUser', () => {
  it('should create an instance', () => {
    expect(new AuthUser()).toBeTruthy();
  });
});
