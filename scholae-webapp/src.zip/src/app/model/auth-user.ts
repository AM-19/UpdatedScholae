export class AuthUser {
    emailId:string;
    password:string;


}
